unit ufrmPrincipal;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.Menus, TDI;

type
  TfrmPrincipal = class(TForm)
    mnuPrincipal: TMainMenu;
    mnuProdutos: TMenuItem;
    mnuClientes: TMenuItem;
    mnuPedidos: TMenuItem;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure mnuProdutosClick(Sender: TObject);
    procedure mnuClientesClick(Sender: TObject);
    procedure mnuPedidosClick(Sender: TObject);
  private
    { Private declarations }
    FTDI: TTDI;
  public
    { Public declarations }
  end;

var
  frmPrincipal: TfrmPrincipal;

implementation

uses
  ufrmConexao, ufrmProduto, ufrmCliente, ufrmPedido;

{$R *.dfm}

procedure TfrmPrincipal.FormCreate(Sender: TObject);
var
  ofrmConexao: TfrmConexao;
begin
  ofrmConexao := TfrmConexao.Create(Self);
  try
    if ofrmConexao.ShowModal = mrCancel then
      Self.Close;
  finally
    FreeAndNil(ofrmConexao);
  end;

  FTDI := TTDI.Create(Self, nil); //Utilizado para mostrar os formularios em formato de abas
  FTDI.MostrarMenuPopup := true;
end;

procedure TfrmPrincipal.FormDestroy(Sender: TObject);
begin
  FreeAndNil(FTDI);

  inherited;
end;

procedure TfrmPrincipal.mnuClientesClick(Sender: TObject);
begin
  FTDI.MostrarFormulario(TfrmCliente, False);
end;

procedure TfrmPrincipal.mnuPedidosClick(Sender: TObject);
begin
  FTDI.MostrarFormulario(TfrmPedido, False);
end;

procedure TfrmPrincipal.mnuProdutosClick(Sender: TObject);
begin
  FTDI.MostrarFormulario(TfrmProduto, False);
end;

end.

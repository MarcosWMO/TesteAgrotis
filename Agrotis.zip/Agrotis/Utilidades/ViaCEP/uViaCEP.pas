unit uViaCEP;

interface

uses REST.Json.Types;

type
  TViaCEP = class
  private
    FLogradouro: string;
    [JSONNameAttribute('ibge')]
    FIBGE: string;
    FBairro: string;
    [JSONNameAttribute('uf')]
    FUF: string;
    [JSONNameAttribute('cep')]
    FCEP: string;
    FLocalidade: string;
    FComplemento: string;
    [JSONNameAttribute('gia')]
    FGIA: string;
    [JSONNameAttribute('ddd')]
    FDDD: string;
    procedure SetBairro(const Value: string);
    procedure SetCEP(const Value: string);
    procedure SetComplemento(const Value: string);
    procedure SetGIA(const Value: string);
    procedure SetIBGE(const Value: string);
    procedure SetLocalidade(const Value: string);
    procedure SetLogradouro(const Value: string);
    procedure SetUF(const Value: string);
    procedure SetDDD(const Value: string);
  public
    property CEP: string read FCEP write SetCEP;
    property Logradouro: string read FLogradouro write SetLogradouro;
    property Complemento: string read FComplemento write SetComplemento;
    property Bairro: string read FBairro write SetBairro;
    property Localidade: string read FLocalidade write SetLocalidade;
    property UF: string read FUF write SetUF;
    property IBGE: string read FIBGE write SetIBGE;
    property GIA: string read FGIA write SetGIA;
    property DDD: string read FDDD write SetDDD;
  end;

implementation

uses REST.Json;

{ TViaCEP}

procedure TViaCEP.SetBairro(const Value: string);
begin
  FBairro := Value;
end;

procedure TViaCEP.SetCEP(const Value: string);
begin
  FCEP := Value;
end;

procedure TViaCEP.SetComplemento(const Value: string);
begin
  FComplemento := Value;
end;

procedure TViaCEP.SetDDD(const Value: string);
begin
  FDDD := Value;
end;

procedure TViaCEP.SetGIA(const Value: string);
begin
  FGIA := Value;
end;

procedure TViaCEP.SetIBGE(const Value: string);
begin
  FIBGE := Value;
end;

procedure TViaCEP.SetLocalidade(const Value: string);
begin
  FLocalidade := Value;
end;

procedure TViaCEP.SetLogradouro(const Value: string);
begin
  FLogradouro := Value;
end;

procedure TViaCEP.SetUF(const Value: string);
begin
  FUF := Value;
end;

end.

unit uViaCEPSOAP;

interface
uses
  IdHTTP, IdSSLOpenSSL, uViaCEP;

type
  TViaCEPSOAP = class
  private
    FIdHTTP: TIdHTTP;
    FIdSSLIOHandlerSocketOpenSSL: TIdSSLIOHandlerSocketOpenSSL;
  public
    constructor Create;
    function Consultar(const sCep: string): TViaCEP;
    destructor Destroy; override;
    function Validar(const sCep: string): Boolean;
  end;

implementation
{ TViaCEP }
uses
  System.Classes, REST.Json, System.SysUtils;

constructor TViaCEPSOAP.Create;
begin
  FIdHTTP := TIdHTTP.Create;
  FIdSSLIOHandlerSocketOpenSSL := TIdSSLIOHandlerSocketOpenSSL.Create;
  FIdHTTP.IOHandler := FIdSSLIOHandlerSocketOpenSSL;
  FIdSSLIOHandlerSocketOpenSSL.SSLOptions.SSLVersions := [sslvTLSv1, sslvTLSv1_1,
     sslvTLSv1_2];
end;

function TViaCEPSOAP.Consultar(const sCep: string): TViaCEP;
const
  URL = 'https://viacep.com.br/ws/%s/json';
  INVALID_CEP = '{'#$A'  "erro": true'#$A'}';
var
  LResponse: TStringStream;
begin
  Result := nil;
  LResponse := TStringStream.Create;
  try
    FIdHTTP.Get(Format(URL, [sCep.Trim]), LResponse);
    if (FIdHTTP.ResponseCode = 200) and
      (not (LResponse.DataString).Equals(INVALID_CEP)) then
    begin
      Result := TJson.JsonToObject<TViaCEP>(UTF8ToString(PAnsiChar(
        AnsiString(LResponse.DataString))));
    end;
  finally
    LResponse.Free;
  end;
end;

function TViaCEPSOAP.Validar(const sCep: string): Boolean;
const
  INVALID_CHARACTER = -1;
begin
  Result := True;
  if sCep.Trim.Length <> 8 then
    Exit(False);
  if StrToIntDef(sCep, INVALID_CHARACTER) = INVALID_CHARACTER then
    Exit(False);
end;

destructor TViaCEPSOAP.Destroy;
begin
  FIdSSLIOHandlerSocketOpenSSL.Free;
  FIdHTTP.Free;
  inherited;
end;

end.

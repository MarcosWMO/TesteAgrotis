program Agrotis;

uses
  Vcl.Forms,
  ufrmPrincipal in 'ufrmPrincipal.pas' {frmPrincipal},
  uCore in 'Bases\uCore.pas',
  uModel in 'Bases\uModel.pas',
  uSingleton in 'Bases\uSingleton.pas',
  PageControlEx in 'Utilidades\TDI\PageControlEx.pas',
  TabCloseButton in 'Utilidades\TDI\TabCloseButton.pas',
  TDI in 'Utilidades\TDI\TDI.pas',
  VisualizaImagensDasGuiasAbertas in 'Utilidades\TDI\VisualizaImagensDasGuiasAbertas.pas',
  udmBase in 'Conexao\udmBase.pas' {dmBase: TDataModule},
  ufrmConexao in 'Conexao\ufrmConexao.pas' {frmConexao},
  ufrmCadastroBase in 'Bases\ufrmCadastroBase.pas' {frmCadastroBase},
  ufrmProduto in 'Cadastros\Produto\ufrmProduto.pas' {frmProduto},
  udmProduto in 'Cadastros\Produto\udmProduto.pas' {dmProduto: TDataModule},
  uProduto in 'Cadastros\Produto\uProduto.pas',
  ufrmCliente in 'Cadastros\Cliente\ufrmCliente.pas' {frmCliente},
  udmCliente in 'Cadastros\Cliente\udmCliente.pas' {dmCliente: TDataModule},
  uCliente in 'Cadastros\Cliente\uCliente.pas',
  uViaCEPSOAP in 'Utilidades\ViaCEP\uViaCEPSOAP.pas',
  uViaCEP in 'Utilidades\ViaCEP\uViaCEP.pas',
  ufrmPedido in 'Cadastros\Pedido\ufrmPedido.pas' {frmPedido},
  udmPedido in 'Cadastros\Pedido\udmPedido.pas' {dmPedido: TDataModule},
  uPedido in 'Cadastros\Pedido\uPedido.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TfrmPrincipal, frmPrincipal);
  Application.Run;
end.


SELECT tipo_operacao.cd_tipo_operacao
      ,tipo_operacao.descricao
  FROM tipo_operacao
 WHERE (:cd_tipo_operacao = 0 OR tipo_operacao.cd_tipo_operacao = :cd_tipo_operacao)


IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='cliente' and xtype='U')
	CREATE TABLE dbo.cliente
	(
		cd_cliente INT NOT NULL IDENTITY(1, 1),
		nm_cliente VARCHAR(200) NOT NULL,
		cep NUMERIC(8) NOT NULL,
		logradouro VARCHAR(200) NULL,
		complemento VARCHAR(200) NULL,
		bairro VARCHAR(200) NULL,
		cidade VARCHAR(200) NULL,
		uf VARCHAR(2) NULL,
		codigo_ibge NUMERIC(7) NULL,
		PRIMARY KEY(cd_cliente)
	);
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='produto' and xtype='U')
	CREATE TABLE dbo.produto
	(
		cd_produto INT NOT NULL IDENTITY(1, 1),
		nm_produto VARCHAR(200) NOT NULL,
		PRIMARY KEY(cd_produto)
	);
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='tipo_operacao' and xtype='U')
	CREATE TABLE dbo.tipo_operacao
	(
		cd_tipo_operacao INT NOT NULL IDENTITY(1, 1),
		descricao VARCHAR(200) NULL,
		PRIMARY KEY(cd_tipo_operacao)
	);

	INSERT INTO dbo.tipo_operacao(descricao) VALUES('Entrada');
	INSERT INTO dbo.tipo_operacao(descricao) VALUES('Sa�da');
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='pedido' and xtype='U')
	CREATE TABLE dbo.pedido
	(
		id_pedido INT NOT NULL IDENTITY(1, 1),
		referencia VARCHAR(200) NULL,
		nr_pedido INT NOT NULL,
		dt_emissao DATE NOT NULL,
		cd_cliente INTEGER NOT NULL,
		cd_tipo_operacao INTEGER NOT NULL,
		vl_total MONEY NOT NULL,
		PRIMARY KEY(id_pedido),
		CONSTRAINT FK_Pedido_Cliente FOREIGN KEY (cd_cliente)
        REFERENCES cliente(cd_cliente),
		CONSTRAINT FK_Pedido_TipOperacao FOREIGN KEY (cd_tipo_operacao)
        REFERENCES tipo_operacao(cd_tipo_operacao) 
	);
GO

IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='item_pedido' and xtype='U')
	CREATE TABLE dbo.item_pedido
	(
		id_item_pedido INT NOT NULL IDENTITY(1, 1),
		id_pedido INT NOT NULL,
		cd_produto INT NOT NULL,
		qtd INT NOT NULL,
		vl_unitario MONEY NOT NULL,
		vl_total MONEY NOT NULL
		PRIMARY KEY(id_item_pedido),
		CONSTRAINT FK_ItemPedido_Pedido FOREIGN KEY (id_pedido)
        REFERENCES pedido(id_pedido),
		CONSTRAINT FK_ItemPedido_Produto FOREIGN KEY (cd_produto)
        REFERENCES produto(cd_produto)
	);
GO
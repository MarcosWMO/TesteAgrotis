unit ufrmCadastroBase;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Data.DB, Vcl.Grids, Vcl.DBGrids,
  Vcl.ExtCtrls, Vcl.DBCtrls, Vcl.ComCtrls;

type
  TfrmCadastroBase = class(TForm)
    navDados: TDBNavigator;
    pnlFundo: TPanel;
    dsDados: TDataSource;
    pcPrimario: TPageControl;
    tsConsulta: TTabSheet;
    tsDados: TTabSheet;
    grConsulta: TDBGrid;
    procedure FormShow(Sender: TObject);
    procedure navDadosClick(Sender: TObject; Button: TNavigateBtn);
    procedure grConsultaDblClick(Sender: TObject);
  private
    { Private declarations }
  protected
    procedure OnNovoRegistro; virtual;
    procedure OnExcluirRegistro; virtual;
    procedure OnAlterarRegistro; virtual;
    procedure OnCancelarAlteracoes; virtual;
    procedure OnSalvarRegistro; virtual;
    procedure OnCancelarAlteracao; virtual;
  public
    { Public declarations }
  end;

var
  frmCadastroBase: TfrmCadastroBase;

implementation

{$R *.dfm}

procedure TfrmCadastroBase.FormShow(Sender: TObject);
begin
  pcPrimario.ActivePageIndex := 0;
end;

procedure TfrmCadastroBase.grConsultaDblClick(Sender: TObject);
begin
  pcPrimario.ActivePage := tsDados;
end;

procedure TfrmCadastroBase.navDadosClick(Sender: TObject; Button: TNavigateBtn);
begin
  case Button of
    nbInsert:
    begin
      OnNovoRegistro;
    end;
    nbDelete:
    begin
      OnExcluirRegistro
    end;
    nbEdit:
    begin
      OnAlterarRegistro;
    end;
    nbPost:
    begin
      OnSalvarRegistro;
    end;
    nbCancel:
    begin
      OnCancelarAlteracao;
    end;
  end;
end;

procedure TfrmCadastroBase.OnAlterarRegistro;
begin
  //Deve ser implementado pelo filho
end;

procedure TfrmCadastroBase.OnCancelarAlteracao;
begin
  //Deve ser implementado pelo filho
end;

procedure TfrmCadastroBase.OnCancelarAlteracoes;
begin
  //Deve ser implementado pelo filho
end;

procedure TfrmCadastroBase.OnExcluirRegistro;
begin
  //Deve ser implementado pelo filho
end;

procedure TfrmCadastroBase.OnNovoRegistro;
begin
  pcPrimario.ActivePage := tsDados;

  //Deve ser implementado pelo filho
end;

procedure TfrmCadastroBase.OnSalvarRegistro;
begin
  pcPrimario.ActivePage := tsConsulta;

  //Deve ser implementado pelo filho
end;

end.

unit uCore;

interface

type
  TAtributo = class
  private
    class function GetAtivo: Integer; static;
    { private declarations }
  public
    { public declarations }
    class property Ativo: Integer read GetAtivo;
  end;

implementation

{ TAtributo }

class function TAtributo.GetAtivo: Integer;
begin
  Result := 1;
end;

end.

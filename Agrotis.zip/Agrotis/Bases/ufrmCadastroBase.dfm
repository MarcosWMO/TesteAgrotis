object frmCadastroBase: TfrmCadastroBase
  Left = 0
  Top = 0
  Caption = 'Cadastro'
  ClientHeight = 201
  ClientWidth = 447
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object navDados: TDBNavigator
    Left = 0
    Top = 0
    Width = 447
    Height = 25
    DataSource = dsDados
    Align = alTop
    TabOrder = 0
    OnClick = navDadosClick
  end
  object pnlFundo: TPanel
    Left = 0
    Top = 25
    Width = 447
    Height = 176
    Align = alClient
    Caption = 'pnlFundo'
    ShowCaption = False
    TabOrder = 1
    object pcPrimario: TPageControl
      Left = 1
      Top = 1
      Width = 445
      Height = 174
      ActivePage = tsConsulta
      Align = alClient
      TabOrder = 0
      object tsConsulta: TTabSheet
        Caption = 'Consulta'
        object grConsulta: TDBGrid
          Left = 0
          Top = 0
          Width = 437
          Height = 146
          Align = alClient
          DataSource = dsDados
          Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgConfirmDelete, dgTitleClick, dgTitleHotTrack]
          TabOrder = 0
          TitleFont.Charset = DEFAULT_CHARSET
          TitleFont.Color = clWindowText
          TitleFont.Height = -11
          TitleFont.Name = 'Tahoma'
          TitleFont.Style = []
          OnDblClick = grConsultaDblClick
        end
      end
      object tsDados: TTabSheet
        Caption = 'Dados'
        ImageIndex = 1
      end
    end
  end
  object dsDados: TDataSource
    Left = 392
    Top = 145
  end
end

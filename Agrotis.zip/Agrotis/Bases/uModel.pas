unit uModel;
interface
uses
  Data.Win.ADODB, Data.DB, System.StrUtils;
type
  TModel = class(TObject)
  private
    { private declarations }
  protected
    { protected declarations }
    procedure RemoverDataPacket(const poQuery: TADOQuery;
      const pasCampos: TArray<string>);
  public
    { public declarations }
  end;
implementation
{ TModel }

procedure TModel.RemoverDataPacket(const poQuery: TADOQuery;
  const pasCampos: TArray<string>);
var
  oField: TField;
  sCampo: String;
begin
  if Length(pasCampos) > 0 then
  begin
    for sCampo in pasCampos do
    begin
      if (sCampo <> '') then
      begin
        oField := poQuery.FindField(sCampo);
        if Assigned(oField) then
        begin
          oField.ProviderFlags := [];
          oField.ReadOnly := False;
          oField.Required := False;
        end;
      end;
    end;
  end;
end;

end.

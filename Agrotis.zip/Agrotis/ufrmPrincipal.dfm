object frmPrincipal: TfrmPrincipal
  Left = 0
  Top = 0
  Caption = 'Agrotis'
  ClientHeight = 201
  ClientWidth = 447
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  Menu = mnuPrincipal
  OldCreateOrder = False
  WindowState = wsMaximized
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 13
  object mnuPrincipal: TMainMenu
    Left = 400
    Top = 16
    object mnuProdutos: TMenuItem
      Caption = 'Produtos'
      OnClick = mnuProdutosClick
    end
    object mnuClientes: TMenuItem
      Caption = 'Clientes'
      OnClick = mnuClientesClick
    end
    object mnuPedidos: TMenuItem
      Caption = 'Pedidos'
      OnClick = mnuPedidosClick
    end
  end
end

unit udmBase;
interface
uses
  System.Classes, FireDAC.Stan.Intf, FireDAC.Stan.Option,
  FireDAC.Stan.Error, FireDAC.UI.Intf, FireDAC.Phys.Intf, FireDAC.Stan.Def,
  FireDAC.Stan.Pool, FireDAC.Stan.Async, FireDAC.Phys, FireDAC.VCLUI.Wait,
  Data.DB, FireDAC.Comp.Client, FireDAC.Phys.MySQLDef, FireDAC.Phys.MySQL,
  Data.Win.ADODB;
type
  TdmBase = class(TDataModule)
    conConexaoPrincipal: TADOConnection;
    procedure DataModuleCreate(Sender: TObject);
    procedure DataModuleDestroy(Sender: TObject);
  private
    FServer: String;
    FDatabase: String;
    FUsername: String;
    FPassword: String;
    function GetConnectionString: String;
    { Private declarations }
  protected
    procedure DefinirConexao(const paoConexao: Array of TADOQuery);
  public
    { Public declarations }
    class function TestarConexao(const psServer, psDatabase, psUsername,
      psPassword: String): Boolean;
    class procedure SalvarConfiguracao(const psServer, psDatabase, psUsername,
      psPassword: String);
    class procedure CarregarConfiguracao(out psServer, psDatabase, psUsername,
      psPassword: String);

    property Server: String read FServer write FServer;
    property Database: String read FDatabase write FDatabase;
    property Username: String read FUsername write FUsername;
    property Password: String read FPassword write FPassword;
    property ConnectionString: String read GetConnectionString;
  end;

var
  dmBase: TdmBase;

implementation
{%CLASSGROUP 'Vcl.Controls.TControl'}
{$R *.dfm}
uses
  IniFiles, System.SysUtils, Vcl.Forms;

{ TdmBase }
class procedure TdmBase.CarregarConfiguracao(out psServer, psDatabase,
  psUsername, psPassword: String);
var
  ini : TIniFile;
begin
  if FileExists(ExtractFilePath(Application.ExeName)+'banco.ini') then
  begin
    ini := TIniFile.Create(ExtractFilePath(Application.ExeName)+'banco.ini');
    try
      psServer := ini.ReadString('configuracoes', 'server', '');
      psDatabase := ini.ReadString('configuracoes', 'database', '');
      psUsername := ini.ReadString('configuracoes', 'user'    , '');
      psPassword := ini.ReadString('configuracoes', 'password', '');
    finally
      FreeAndNil(ini);
    end;
  end;
end;

procedure TdmBase.DataModuleCreate(Sender: TObject);
begin
  CarregarConfiguracao(FServer, FDatabase, FUsername, FPassword);
  conConexaoPrincipal.ConnectionString := ConnectionString;
  conConexaoPrincipal.Open;
end;

procedure TdmBase.DataModuleDestroy(Sender: TObject);
begin
  conConexaoPrincipal.Close;
end;

procedure TdmBase.DefinirConexao(const paoConexao: array of TADOQuery);
var
  I: Integer;
begin
  for I := 0 to High(paoConexao) do
    paoConexao[I].Connection := conConexaoPrincipal;
end;

function TdmBase.GetConnectionString: String;
begin
  if (FUsername = '') and (FPassword = '') then
  begin
    Result := 'Provider=SQLOLEDB.1;Integrated Security=SSPI;' +
    'Persist Security Info=False;Initial Catalog=' + FDatabase + ';' +
    'Data Source=' +FServer;
  end
  else
  begin
    Result := 'Provider=SQLOLEDB.1;Password=' + FPassword + 'Persist Security Info=False;' +
      'User ID=' + FUsername + 'Initial Catalog=' + FDatabase + ';' +
      'Data Source=' +FServer;
  end;
end;

class procedure TdmBase.SalvarConfiguracao(const psServer, psDatabase,
  psUsername, psPassword: String);
var
  ini : TIniFile;
begin
  ini := TIniFile.Create(ExtractFilePath(Application.ExeName)+'banco.ini');
  try
    ini.WriteString('configuracoes', 'server', psServer);
    ini.WriteString('configuracoes', 'database', psDatabase);
    ini.WriteString('configuracoes', 'user'    , psUsername);
    ini.WriteString('configuracoes', 'password', psPassword);
  finally
    FreeAndNil(ini);
  end;
end;

class function TdmBase.TestarConexao(const psServer, psDatabase, psUsername,
  psPassword: String): Boolean;
var
  oConTeste: TADOConnection;
begin
  oConTeste := TADOConnection.Create(nil);
  try
    oConTeste.ConnectionString :=
    'Provider=SQLOLEDB.1;Integrated Security=SSPI;' +
    'Persist Security Info=False;Initial Catalog=' + psDataBase + ';' +
    'Data Source=' + psServer;
    oConTeste.LoginPrompt := False;
    oConTeste.Connected := True;

    Result := oConTeste.Connected;
  finally
    FreeAndNil(oConTeste);
  end;
end;

end.

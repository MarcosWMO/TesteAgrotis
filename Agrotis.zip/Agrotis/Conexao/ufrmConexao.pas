unit ufrmConexao;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.ExtCtrls, Vcl.StdCtrls;

type
  TfrmConexao = class(TForm)
    pnlFundo: TPanel;
    gpInfoBanco: TGroupBox;
    edtServer: TLabeledEdit;
    edtDatabase: TLabeledEdit;
    edtUsername: TLabeledEdit;
    edtPassword: TLabeledEdit;
    btnConectar: TButton;
    btnCancelar: TButton;
    procedure btnConectarClick(Sender: TObject);
    procedure btnCancelarClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
    procedure CarregarConfiguracao;
  public
    { Public declarations }
  end;

var
  frmConexao: TfrmConexao;

implementation

uses
  udmBase;

{$R *.dfm}

procedure TfrmConexao.btnCancelarClick(Sender: TObject);
begin
  ModalResult := mrCancel;
end;

procedure TfrmConexao.btnConectarClick(Sender: TObject);
begin
  if TDMBase.TestarConexao(edtServer.Text, edtDatabase.Text, edtUsername.Text,
    edtPassword.Text) then
  begin
    TDMBase.SalvarConfiguracao(edtServer.Text, edtDatabase.Text,
      edtUsername.Text, edtPassword.Text);
    ModalResult := mrOk;
  end;
end;

procedure TfrmConexao.CarregarConfiguracao;
var
  sServer, sDatabase, sUsername, sPassword: String;
begin
  TDMBase.CarregarConfiguracao(sServer, sDatabase, sUsername, sPassword);

  edtServer.Text := sServer;
  edtDatabase.Text := sDatabase;
  edtUsername.Text := sUsername;
  edtPassword.Text := sPassword;
end;

procedure TfrmConexao.FormCreate(Sender: TObject);
begin
  CarregarConfiguracao;
end;

end.

object frmConexao: TfrmConexao
  Left = 0
  Top = 0
  BorderIcons = [biSystemMenu]
  Caption = 'Conex'#227'o'
  ClientHeight = 133
  ClientWidth = 256
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object pnlFundo: TPanel
    Left = 0
    Top = 0
    Width = 256
    Height = 133
    Align = alClient
    Caption = 'pnlFundo'
    ShowCaption = False
    TabOrder = 0
    object gpInfoBanco: TGroupBox
      Left = 1
      Top = 1
      Width = 254
      Height = 131
      Align = alClient
      Caption = 'Informa'#231#245'es do Banco de Dados'
      TabOrder = 0
      object edtServer: TLabeledEdit
        Left = 4
        Top = 32
        Width = 121
        Height = 21
        EditLabel.Width = 32
        EditLabel.Height = 13
        EditLabel.Caption = 'Server'
        TabOrder = 0
      end
      object edtDatabase: TLabeledEdit
        Left = 127
        Top = 32
        Width = 121
        Height = 21
        EditLabel.Width = 46
        EditLabel.Height = 13
        EditLabel.Caption = 'DataBase'
        TabOrder = 1
      end
      object edtUsername: TLabeledEdit
        Left = 4
        Top = 72
        Width = 121
        Height = 21
        EditLabel.Width = 49
        EditLabel.Height = 13
        EditLabel.Caption = 'UserName'
        TabOrder = 2
      end
      object edtPassword: TLabeledEdit
        Left = 127
        Top = 72
        Width = 121
        Height = 21
        EditLabel.Width = 46
        EditLabel.Height = 13
        EditLabel.Caption = 'Password'
        PasswordChar = '*'
        TabOrder = 3
      end
      object btnConectar: TButton
        Left = 127
        Top = 99
        Width = 121
        Height = 25
        Caption = 'Conectar'
        TabOrder = 4
        OnClick = btnConectarClick
      end
      object btnCancelar: TButton
        Left = 4
        Top = 99
        Width = 121
        Height = 25
        Caption = 'Cancelar'
        TabOrder = 5
        OnClick = btnCancelarClick
      end
    end
  end
end

object dmBase: TdmBase
  OldCreateOrder = False
  OnCreate = DataModuleCreate
  OnDestroy = DataModuleDestroy
  Height = 175
  Width = 263
  object conConexaoPrincipal: TADOConnection
    LoginPrompt = False
    Provider = 'SQLOLEDB'
    Left = 56
    Top = 24
  end
end

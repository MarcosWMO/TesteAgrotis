unit udmPedido;

interface

uses
  System.SysUtils, System.Classes, udmBase, Data.DB, Data.Win.ADODB,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf,
  FireDAC.Stan.Async, FireDAC.DApt, FireDAC.Comp.DataSet, FireDAC.Comp.Client;

type
  TdmPedido = class(TdmBase)
    qyPedido: TADOQuery;
    qyClientes: TADOQuery;
    qyTipoOperacao: TADOQuery;
    qyAux: TADOQuery;
    qyProduto: TADOQuery;
    dsPedido: TDataSource;
    qyItens: TADOQuery;
    procedure DataModuleCreate(Sender: TObject);
    procedure qyPedidoNewRecord(DataSet: TDataSet);
    procedure qyItensAfterOpen(DataSet: TDataSet);
    procedure qyItensAfterDelete(DataSet: TDataSet);
    procedure qyItensAfterPost(DataSet: TDataSet);
  private
    { Private declarations }

    procedure CalcularValorTotal;
    procedure OnChangeValorTotal(Sender: TField);
  public
    { Public declarations }
    procedure ConsultarPedido;
    procedure ConsultarCliente;
    procedure ConsultarTipoOperacao;
    procedure ConsultarProduto;
  end;

var
  dmPedido: TdmPedido;

implementation

{%CLASSGROUP 'Vcl.Controls.TControl'}

{$R *.dfm}

uses
  uPedido, uCliente, uProduto;

procedure TdmPedido.CalcularValorTotal;
var
  vValorTotal: Double;
begin
  vValorTotal := 0;
  qyItens.DisableControls;
  try
    qyPedido.Edit;
    qyItens.First;

    while not qyItens.Eof do
    begin
      vValorTotal := vValorTotal + qyItens.FieldByName('vl_total').AsFloat;
      qyItens.Next;
    end;

    qyPedido.FieldByName('vl_total').AsFloat := vValorTotal;
    qyPedido.Post;
  finally
    qyItens.EnableControls;
  end;
end;

procedure TdmPedido.ConsultarCliente;
begin
  TClienteSingleton.GetInstance.ConsultarCliente(qyClientes);
end;

procedure TdmPedido.ConsultarPedido;
begin
  TPedidoSingleton.GetInstance.ConsultarPedido(qyPedido);
  TPedidoSingleton.GetInstance.ConsultarItensPedido(qyItens);
end;

procedure TdmPedido.ConsultarProduto;
begin
  TProdutoSingleton.GetInstance.ConsultarProduto(qyProduto);
end;

procedure TdmPedido.ConsultarTipoOperacao;
begin
  TPedidoSingleton.GetInstance.ConsultarTipoOperacao(qyTipoOperacao);
end;

procedure TdmPedido.DataModuleCreate(Sender: TObject);
begin
  inherited;

  DefinirConexao([qyPedido, qyClientes, qyTipoOperacao, qyAux, qyProduto,
    qyItens]);
end;

procedure TdmPedido.OnChangeValorTotal(Sender: TField);
begin
  if Sender.DataSet.State <> dsBrowse then
  begin
    Sender.DataSet.FieldByName('vl_total').AsFloat :=
      Sender.DataSet.FieldByName('qtd').AsFloat *
      Sender.DataSet.FieldByName('vl_unitario').AsFloat
  end;
end;

procedure TdmPedido.qyItensAfterDelete(DataSet: TDataSet);
begin
  inherited;

  CalcularValorTotal;
end;

procedure TdmPedido.qyItensAfterOpen(DataSet: TDataSet);
begin
  inherited;

  DataSet.FieldByName('vl_unitario').OnChange := OnChangeValorTotal;
  DataSet.FieldByName('qtd').OnChange := OnChangeValorTotal;
end;

procedure TdmPedido.qyItensAfterPost(DataSet: TDataSet);
begin
  inherited;

  CalcularValorTotal;
end;

procedure TdmPedido.qyPedidoNewRecord(DataSet: TDataSet);
begin
  inherited;

  DataSet.FieldByName('vl_total').AsFloat := 0;
end;

end.

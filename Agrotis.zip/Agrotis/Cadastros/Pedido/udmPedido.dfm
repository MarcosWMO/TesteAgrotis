inherited dmPedido: TdmPedido
  OldCreateOrder = True
  Height = 227
  Width = 325
  object qyPedido: TADOQuery
    OnNewRecord = qyPedidoNewRecord
    Parameters = <>
    Left = 152
    Top = 24
  end
  object qyClientes: TADOQuery
    Parameters = <>
    Left = 160
    Top = 88
  end
  object qyTipoOperacao: TADOQuery
    Parameters = <>
    Left = 88
    Top = 88
  end
  object qyAux: TADOQuery
    Parameters = <>
    Left = 24
    Top = 96
  end
  object qyProduto: TADOQuery
    Parameters = <>
    Left = 216
    Top = 48
  end
  object dsPedido: TDataSource
    DataSet = qyPedido
    Left = 248
    Top = 152
  end
  object qyItens: TADOQuery
    AfterOpen = qyItensAfterOpen
    AfterPost = qyItensAfterPost
    AfterDelete = qyItensAfterDelete
    DataSource = dsPedido
    Parameters = <>
    Left = 128
    Top = 160
  end
end

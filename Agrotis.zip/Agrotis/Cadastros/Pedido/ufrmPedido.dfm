inherited frmPedido: TfrmPedido
  Caption = 'Cadastro de Pedidos'
  ClientHeight = 413
  ClientWidth = 703
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  ExplicitWidth = 719
  ExplicitHeight = 452
  PixelsPerInch = 96
  TextHeight = 13
  inherited navDados: TDBNavigator
    Width = 703
    Hints.Strings = ()
    ExplicitWidth = 703
  end
  inherited pnlFundo: TPanel
    Width = 703
    Height = 388
    ExplicitWidth = 703
    ExplicitHeight = 388
    inherited pcPrimario: TPageControl
      Width = 701
      Height = 386
      ExplicitWidth = 701
      ExplicitHeight = 386
      inherited tsConsulta: TTabSheet
        ExplicitWidth = 693
        ExplicitHeight = 358
        inherited grConsulta: TDBGrid
          Width = 693
          Height = 358
          Columns = <
            item
              Expanded = False
              FieldName = 'id_pedido'
              Title.Caption = 'Pedido'
              Width = 67
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'nr_pedido'
              Title.Caption = 'Nr. Pedido'
              Width = 78
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'referencia'
              Title.Caption = 'Refer'#234'ncia'
              Width = 92
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'dt_emissao'
              Title.Caption = 'Dt. Emiss'#227'o'
              Width = 96
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'cd_cliente'
              Title.Caption = 'C'#243'd. Cliente'
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'descricao'
              Title.Caption = 'T. Opera'#231#227'o'
              Width = 74
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'vl_total'
              Title.Caption = 'Vl. Total'
              Width = 75
              Visible = True
            end>
        end
      end
      inherited tsDados: TTabSheet
        ExplicitWidth = 693
        ExplicitHeight = 358
        object lblreferencia: TLabel
          Left = 126
          Top = 2
          Width = 52
          Height = 13
          Caption = 'Refer'#234'ncia'
        end
        object lblnr_pedido: TLabel
          Left = 3
          Top = 2
          Width = 50
          Height = 13
          Caption = 'Nr. Pedido'
        end
        object lbldt_emissao: TLabel
          Left = 249
          Top = 2
          Width = 56
          Height = 13
          Caption = 'Dt. Emiss'#227'o'
        end
        object lblCliente: TLabel
          Left = 3
          Top = 42
          Width = 33
          Height = 13
          Caption = 'Cliente'
        end
        object lblcd_tipo_operacao: TLabel
          Left = 126
          Top = 42
          Width = 70
          Height = 13
          Caption = 'Tipo Opera'#231#227'o'
        end
        object lblvl_total: TLabel
          Left = 249
          Top = 42
          Width = 45
          Height = 13
          Caption = 'Vl. Total'
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
        end
        object lblAviso: TLabel
          Left = 5
          Top = 328
          Width = 375
          Height = 13
          Caption = 'Para adi'#231#227'o dos itens, deve-se salvar o cabe'#231'alho primeiramente*'
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clRed
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
        end
        object edtreferencia: TDBEdit
          Left = 126
          Top = 16
          Width = 121
          Height = 21
          DataField = 'referencia'
          DataSource = dsDados
          TabOrder = 1
        end
        object edtnr_pedido: TDBEdit
          Left = 3
          Top = 16
          Width = 121
          Height = 21
          DataField = 'nr_pedido'
          DataSource = dsDados
          TabOrder = 0
        end
        object edtdt_emissao: TDBEdit
          Left = 249
          Top = 16
          Width = 121
          Height = 21
          DataField = 'dt_emissao'
          DataSource = dsDados
          TabOrder = 2
        end
        object edtvl_total: TDBEdit
          Left = 249
          Top = 56
          Width = 121
          Height = 21
          DataField = 'vl_total'
          DataSource = dsDados
          Enabled = False
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 5
        end
        object lckcd_cliente: TDBLookupComboBox
          Left = 3
          Top = 56
          Width = 121
          Height = 21
          DataField = 'cd_cliente'
          DataSource = dsDados
          KeyField = 'cd_cliente'
          ListField = 'nm_cliente'
          ListSource = dsClientes
          TabOrder = 3
        end
        object lckcd_tipo_operacao: TDBLookupComboBox
          Left = 126
          Top = 56
          Width = 121
          Height = 21
          DataField = 'cd_tipo_operacao'
          DataSource = dsDados
          KeyField = 'cd_tipo_operacao'
          ListField = 'descricao'
          ListSource = dsTipoOperacao
          TabOrder = 4
        end
        object gbItensPedido: TGroupBox
          Left = 3
          Top = 83
          Width = 367
          Height = 238
          Caption = 'Itens do Pedido'
          Enabled = False
          TabOrder = 6
          object pnlItens: TPanel
            Left = 2
            Top = 15
            Width = 363
            Height = 42
            Align = alTop
            Caption = 'pnlItens'
            ShowCaption = False
            TabOrder = 0
            object Label1: TLabel
              Left = 126
              Top = 0
              Width = 56
              Height = 13
              Caption = 'Quantidade'
            end
            object lblProduto: TLabel
              Left = 3
              Top = 0
              Width = 38
              Height = 13
              Caption = 'Produto'
            end
            object lblVlUnitario: TLabel
              Left = 244
              Top = 0
              Width = 52
              Height = 13
              Caption = 'Vl. Unit'#225'rio'
            end
            object edtqtd: TDBEdit
              Left = 126
              Top = 15
              Width = 116
              Height = 21
              DataField = 'qtd'
              DataSource = dsItens
              TabOrder = 1
            end
            object lckProduto: TDBLookupComboBox
              Left = 3
              Top = 15
              Width = 121
              Height = 21
              DataField = 'cd_produto'
              DataSource = dsItens
              KeyField = 'cd_produto'
              ListField = 'nm_produto'
              ListSource = dsProdutos
              TabOrder = 0
            end
            object edtVlUnitario: TDBEdit
              Left = 244
              Top = 15
              Width = 116
              Height = 21
              DataField = 'vl_unitario'
              DataSource = dsItens
              TabOrder = 2
            end
          end
          object DBGrid1: TDBGrid
            Left = 2
            Top = 82
            Width = 363
            Height = 154
            Align = alClient
            DataSource = dsItens
            Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgConfirmDelete, dgTitleClick, dgTitleHotTrack]
            TabOrder = 1
            TitleFont.Charset = DEFAULT_CHARSET
            TitleFont.Color = clWindowText
            TitleFont.Height = -11
            TitleFont.Name = 'Tahoma'
            TitleFont.Style = []
            Columns = <
              item
                Expanded = False
                FieldName = 'cd_produto'
                Title.Caption = 'Produto'
                Visible = True
              end
              item
                Expanded = False
                FieldName = 'qtd'
                Title.Caption = 'Qtd.'
                Width = 39
                Visible = True
              end
              item
                Expanded = False
                FieldName = 'vl_unitario'
                Title.Caption = 'Vl. Unit'#225'rio'
                Width = 67
                Visible = True
              end
              item
                Expanded = False
                FieldName = 'vl_total'
                Title.Caption = 'Vl. Total'
                Width = 59
                Visible = True
              end>
          end
          object DBNavigator1: TDBNavigator
            Left = 2
            Top = 57
            Width = 363
            Height = 25
            DataSource = dsItens
            Align = alTop
            TabOrder = 2
          end
        end
      end
    end
  end
  inherited dsDados: TDataSource
    OnStateChange = dsDadosStateChange
    Left = 648
    Top = 169
  end
  object dsClientes: TDataSource
    Left = 645
    Top = 114
  end
  object dsTipoOperacao: TDataSource
    Left = 645
    Top = 58
  end
  object dsProdutos: TDataSource
    Left = 645
    Top = 226
  end
  object dsItens: TDataSource
    Left = 645
    Top = 282
  end
end

unit uPedido;

interface

uses
  uModel, FireDAC.Comp.Client, uSingleton,  Data.Win.ADODB;

type
  TPedido = class(TModel)
  private
    { private declarations }
  public
    { public declarations }
    procedure ConsultarPedido(const poQuery: TADOQuery;
      const piid_pedido: Int64 = 0);
    procedure ConsultarTipoOperacao(const poQuery: TADOQuery;
      const piCd_TipoOperacao: Integer = 0);
    procedure ConsultarItensPedido(const poQuery: TADOQuery);
  end;

  TPedidoSingleton = class(TSingleton<TPedido>);

implementation

{ TPedido }

procedure TPedido.ConsultarItensPedido(const poQuery: TADOQuery);
begin
  if Assigned(poQuery) then
  begin
    poQuery.Close;
    poQuery.SQL.Text :=
      'SELECT item_pedido.id_item_pedido' + sLineBreak +
      '      ,item_pedido.id_pedido' + sLineBreak +
      '      ,item_pedido.cd_produto' + sLineBreak +
      '      ,item_pedido.qtd' + sLineBreak +
      '      ,item_pedido.vl_unitario' + sLineBreak +
      '      ,item_pedido.vl_total' + sLineBreak +
      '  FROM item_pedido' + sLineBreak +
      ' WHERE item_pedido.id_pedido = :id_pedido';
    poQuery.Open;

  end;
end;

procedure TPedido.ConsultarPedido(const poQuery: TADOQuery;
  const piid_pedido: Int64);
begin
  if Assigned(poQuery) then
  begin
    poQuery.Close;
    poQuery.SQL.Text :=
      'SELECT pedido.id_pedido' + sLineBreak +
      '      ,pedido.referencia' + sLineBreak +
      '      ,pedido.nr_pedido' + sLineBreak +
      '      ,pedido.dt_emissao' + sLineBreak +
      '      ,pedido.cd_cliente' + sLineBreak +
      '      ,pedido.cd_tipo_operacao' + sLineBreak +
      '      ,pedido.vl_total' + sLineBreak +
      '  FROM pedido' + sLineBreak +
      ' WHERE (:id_pedido = 0 OR pedido.id_pedido = :id_pedido)';
    poQuery.Parameters.ParamByName('id_pedido').Value := piid_pedido;
    poQuery.Open;
  end;
end;

procedure TPedido.ConsultarTipoOperacao(const poQuery: TADOQuery;
  const piCd_TipoOperacao: Integer = 0);
begin
  if Assigned(poQuery) then
  begin
    poQuery.Close;
    poQuery.SQL.Text :=
      'SELECT tipo_operacao.cd_tipo_operacao' + sLineBreak +
      '      ,tipo_operacao.descricao' + sLineBreak +
      '  FROM tipo_operacao' + sLineBreak +
      ' WHERE (:cd_tipo_operacao = 0 OR tipo_operacao.cd_tipo_operacao = :cd_tipo_operacao)';
    poQuery.Parameters.ParamByName('cd_tipo_operacao').Value := piCd_TipoOperacao;
    poQuery.Open;
  end;
end;

end.

unit ufrmPedido;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, ufrmCadastroBase, Data.DB, Vcl.Grids,
  Vcl.DBGrids, Vcl.ComCtrls, Vcl.ExtCtrls, Vcl.DBCtrls, udmPedido, Vcl.StdCtrls,
  Vcl.Mask;

type
  TfrmPedido = class(TfrmCadastroBase)
    lblreferencia: TLabel;
    edtreferencia: TDBEdit;
    lblnr_pedido: TLabel;
    edtnr_pedido: TDBEdit;
    lbldt_emissao: TLabel;
    edtdt_emissao: TDBEdit;
    lblCliente: TLabel;
    lblcd_tipo_operacao: TLabel;
    lblvl_total: TLabel;
    edtvl_total: TDBEdit;
    lckcd_cliente: TDBLookupComboBox;
    lckcd_tipo_operacao: TDBLookupComboBox;
    dsClientes: TDataSource;
    dsTipoOperacao: TDataSource;
    gbItensPedido: TGroupBox;
    pnlItens: TPanel;
    DBGrid1: TDBGrid;
    Label1: TLabel;
    edtqtd: TDBEdit;
    lblProduto: TLabel;
    lckProduto: TDBLookupComboBox;
    lblVlUnitario: TLabel;
    edtVlUnitario: TDBEdit;
    dsProdutos: TDataSource;
    dsItens: TDataSource;
    DBNavigator1: TDBNavigator;
    lblAviso: TLabel;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure dsDadosStateChange(Sender: TObject);
  private
    { Private declarations }
    FdmPedido: TdmPedido;

    procedure ConsultarDados;
    procedure DefinirDataSets;
  public
    { Public declarations }

    procedure OnNovoRegistro; override;
  end;

var
  frmPedido: TfrmPedido;

implementation

{$R *.dfm}

procedure TfrmPedido.ConsultarDados;
begin
  FdmPedido.ConsultarCliente;
  FdmPedido.ConsultarTipoOperacao;
  FdmPedido.ConsultarProduto;
  FdmPedido.ConsultarPedido;
end;

procedure TfrmPedido.DefinirDataSets;
begin
  dsDados.DataSet := FdmPedido.qyPedido;
  dsClientes.DataSet := FdmPedido.qyClientes;
  dsTipoOperacao.DataSet := FdmPedido.qyTipoOperacao;
  dsProdutos.DataSet := FdmPedido.qyProduto;
  dsItens.DataSet := FdmPedido.qyItens;
end;

procedure TfrmPedido.dsDadosStateChange(Sender: TObject);
begin
  inherited;

  gbItensPedido.Enabled := (dsDados.State <> dsInsert) and
    (not FdmPedido.qyPedido.IsEmpty);
end;

procedure TfrmPedido.FormCreate(Sender: TObject);
begin
  inherited;

  FdmPedido := TdmPedido.Create(Self);
  DefinirDataSets;
  ConsultarDados;
end;

procedure TfrmPedido.FormDestroy(Sender: TObject);
begin
  inherited;

  FreeAndNil(FdmPedido);
end;

procedure TfrmPedido.OnNovoRegistro;
begin
  inherited OnNovoRegistro;

  edtnr_pedido.SetFocus;
end;

end.

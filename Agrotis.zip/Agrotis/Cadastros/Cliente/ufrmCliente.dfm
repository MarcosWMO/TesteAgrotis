inherited frmCliente: TfrmCliente
  Caption = 'Cadastro de Cliente'
  ClientHeight = 352
  ClientWidth = 590
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  ExplicitWidth = 606
  ExplicitHeight = 391
  PixelsPerInch = 96
  TextHeight = 13
  inherited navDados: TDBNavigator
    Width = 590
    Hints.Strings = ()
    ExplicitWidth = 590
  end
  inherited pnlFundo: TPanel
    Width = 590
    Height = 327
    ExplicitWidth = 590
    ExplicitHeight = 327
    inherited pcPrimario: TPageControl
      Width = 588
      Height = 325
      ExplicitWidth = 588
      ExplicitHeight = 325
      inherited tsConsulta: TTabSheet
        ExplicitWidth = 580
        ExplicitHeight = 297
        inherited grConsulta: TDBGrid
          Width = 580
          Height = 297
          Columns = <
            item
              Expanded = False
              FieldName = 'cd_cliente'
              Title.Caption = 'C'#243'digo'
              Width = 43
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'nm_cliente'
              Title.Caption = 'Nome'
              Width = 206
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'cep'
              Title.Caption = 'CEP'
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'logradouro'
              Title.Caption = 'Logradouro'
              Width = 171
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'complemento'
              Title.Caption = 'Complemento'
              Width = 169
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'bairro'
              Title.Caption = 'Bairro'
              Width = 118
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'cidade'
              Title.Caption = 'Cidade'
              Width = 102
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'uf'
              Title.Caption = 'UF'
              Width = 31
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'codigo_ibge'
              Title.Caption = 'C'#243'digo IBGE'
              Width = 122
              Visible = True
            end>
        end
      end
      inherited tsDados: TTabSheet
        ExplicitWidth = 580
        ExplicitHeight = 297
        object lblCodigo: TLabel
          Left = 3
          Top = 2
          Width = 33
          Height = 13
          Caption = 'C'#243'digo'
        end
        object lblnm_cliente: TLabel
          Left = 126
          Top = 2
          Width = 27
          Height = 13
          Caption = 'Nome'
        end
        object lblCEP: TLabel
          Left = 3
          Top = 42
          Width = 19
          Height = 13
          Caption = 'CEP'
        end
        object lbllogradouro: TLabel
          Left = 126
          Top = 42
          Width = 55
          Height = 13
          Caption = 'Logradouro'
        end
        object lblcomplemento: TLabel
          Left = 291
          Top = 42
          Width = 65
          Height = 13
          Caption = 'Complemento'
        end
        object lblbairro: TLabel
          Left = 3
          Top = 82
          Width = 28
          Height = 13
          Caption = 'Bairro'
        end
        object lblcidade: TLabel
          Left = 126
          Top = 82
          Width = 33
          Height = 13
          Caption = 'Cidade'
        end
        object lbluf: TLabel
          Left = 249
          Top = 82
          Width = 13
          Height = 13
          Caption = 'UF'
        end
        object lblcodigo_ibge: TLabel
          Left = 291
          Top = 82
          Width = 59
          Height = 13
          Caption = 'C'#243'digo IBGE'
        end
        object edtcd_cliente: TDBEdit
          Left = 3
          Top = 16
          Width = 121
          Height = 21
          TabStop = False
          DataField = 'cd_cliente'
          DataSource = dsDados
          Enabled = False
          ReadOnly = True
          TabOrder = 0
        end
        object edtnm_cliente: TDBEdit
          Left = 126
          Top = 16
          Width = 328
          Height = 21
          DataField = 'nm_cliente'
          DataSource = dsDados
          TabOrder = 1
        end
        object edtcep: TDBEdit
          Left = 3
          Top = 56
          Width = 121
          Height = 21
          DataField = 'cep'
          DataSource = dsDados
          MaxLength = 8
          TabOrder = 2
        end
        object edtlogradouro: TDBEdit
          Left = 126
          Top = 56
          Width = 163
          Height = 21
          DataField = 'logradouro'
          DataSource = dsDados
          TabOrder = 3
        end
        object edtcomplemento: TDBEdit
          Left = 291
          Top = 55
          Width = 163
          Height = 21
          DataField = 'complemento'
          DataSource = dsDados
          TabOrder = 4
        end
        object edtbairro: TDBEdit
          Left = 3
          Top = 96
          Width = 121
          Height = 21
          DataField = 'bairro'
          DataSource = dsDados
          TabOrder = 5
        end
        object edtcidade: TDBEdit
          Left = 126
          Top = 96
          Width = 121
          Height = 21
          DataField = 'cidade'
          DataSource = dsDados
          TabOrder = 6
        end
        object edtuf: TDBEdit
          Left = 249
          Top = 96
          Width = 40
          Height = 21
          DataField = 'uf'
          DataSource = dsDados
          TabOrder = 7
        end
        object edtcodigo_ibge: TDBEdit
          Left = 291
          Top = 96
          Width = 163
          Height = 21
          DataField = 'codigo_ibge'
          DataSource = dsDados
          TabOrder = 8
        end
      end
    end
  end
  inherited dsDados: TDataSource
    Left = 544
    Top = 265
  end
end

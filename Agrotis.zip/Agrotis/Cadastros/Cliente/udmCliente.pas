unit udmCliente;

interface

uses
  System.SysUtils, System.Classes, udmBase, Data.DB, Data.Win.ADODB;

type
  TdmCliente = class(TdmBase)
    qyCliente: TADOQuery;
    procedure DataModuleCreate(Sender: TObject);
    procedure qyClienteAfterOpen(DataSet: TDataSet);
  private
    { Private declarations }

    function ConsultarCEP(const sCep: String): Boolean;
    procedure OnChangeCEP(Sender: TField);
  public
    { Public declarations }
    procedure ConsultarCliente;
  end;

var
  dmCliente: TdmCliente;

implementation

{%CLASSGROUP 'Vcl.Controls.TControl'}

{$R *.dfm}

uses
  uCliente, Vcl.Dialogs, uViaCEP, uViaCEPSOAP;

function TdmCliente.ConsultarCEP(const sCep: String): Boolean;
var
  oViaCEP: TViaCEP;
  oViaCEPSOAP: TViaCEPSOAP;
begin
  oViaCEPSOAP := TViaCEPSOAP.Create;
  try
    Result := oViaCEPSOAP.Validar(sCep);

    if Result then
    begin
      oViaCEP := oViaCEPSOAP.Consultar(sCep);

      if Assigned(oViaCEP) then
      begin
        qyCliente.FieldByName('logradouro').AsString := oViaCEP.Logradouro;
        qyCliente.FieldByName('complemento').AsString := oViaCEP.Complemento;
        qyCliente.FieldByName('bairro').AsString := oViaCEP.Bairro;
        qyCliente.FieldByName('cidade').AsString := oViaCEP.Localidade;
        qyCliente.FieldByName('uf').AsString := oViaCEP.UF;
        qyCliente.FieldByName('codigo_ibge').AsInteger := oViaCEP.IBGE.ToInteger;
      end
      else
        Result := False;
    end;
  finally
    FreeAndNil(oViaCEPSOAP);
  end;
end;

procedure TdmCliente.ConsultarCliente;
begin
  TClienteSingleton.GetInstance.ConsultarCliente(qyCliente);
end;

procedure TdmCliente.DataModuleCreate(Sender: TObject);
begin
  inherited;

  DefinirConexao([qyCliente])
end;

procedure TdmCliente.OnChangeCEP(Sender: TField);
begin
  if Sender.DataSet.State <> dsBrowse then
  begin
    if not ConsultarCEP(Sender.AsString) then
    begin
      ShowMessage('CEP Inv�lido');
      Sender.FocusControl;
    end;
  end;
end;

procedure TdmCliente.qyClienteAfterOpen(DataSet: TDataSet);
begin
  inherited;

  qyCliente.FieldByName('cep').OnChange := OnChangeCEP;
end;

end.

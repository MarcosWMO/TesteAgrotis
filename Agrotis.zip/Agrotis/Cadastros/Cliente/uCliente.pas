unit uCliente;

interface

uses
  uModel, FireDAC.Comp.Client, uSingleton,  Data.Win.ADODB;

type
  TCliente = class(TModel)
  private
    { private declarations }
  public
    { public declarations }
    procedure ConsultarCliente(const poQuery: TADOQuery;
      const picd_cliente: Int64 = 0);
  end;

  TClienteSingleton = class(TSingleton<TCliente>);


implementation

{ TCliente }

procedure TCliente.ConsultarCliente(const poQuery: TADOQuery;
  const picd_cliente: Int64);
begin
  if Assigned(poQuery) then
  begin
    poQuery.Close;
    poQuery.SQL.Text :=
      'SELECT cliente.cd_cliente' + sLineBreak +
      '      ,cliente.nm_cliente' + sLineBreak +
      '      ,cliente.cep' + sLineBreak +
      '      ,cliente.logradouro' + sLineBreak +
      '      ,cliente.complemento' + sLineBreak +
      '      ,cliente.bairro' + sLineBreak +
      '      ,cliente.cidade' + sLineBreak +
      '      ,cliente.uf' + sLineBreak +
      '      ,cliente.codigo_ibge' + sLineBreak +
      '  FROM cliente' + sLineBreak +
      ' WHERE (:cd_cliente = 0 OR cliente.cd_cliente = :cd_cliente)';
    poQuery.Parameters.ParamByName('cd_cliente').Value := picd_cliente;
    poQuery.Open;
  end;
end;

initialization

finalization
  TClienteSingleton.ReleaseInstance;

end.

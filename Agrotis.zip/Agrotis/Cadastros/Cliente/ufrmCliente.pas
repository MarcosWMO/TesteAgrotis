unit ufrmCliente;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, ufrmCadastroBase, Data.DB, Vcl.Grids,
  Vcl.DBGrids, Vcl.ComCtrls, Vcl.ExtCtrls, Vcl.DBCtrls, udmCliente,
  Vcl.StdCtrls, Vcl.Mask;

type
  TfrmCliente = class(TfrmCadastroBase)
    lblCodigo: TLabel;
    edtcd_cliente: TDBEdit;
    lblnm_cliente: TLabel;
    edtnm_cliente: TDBEdit;
    lblCEP: TLabel;
    edtcep: TDBEdit;
    lbllogradouro: TLabel;
    edtlogradouro: TDBEdit;
    lblcomplemento: TLabel;
    edtcomplemento: TDBEdit;
    lblbairro: TLabel;
    edtbairro: TDBEdit;
    lblcidade: TLabel;
    edtcidade: TDBEdit;
    lbluf: TLabel;
    edtuf: TDBEdit;
    lblcodigo_ibge: TLabel;
    edtcodigo_ibge: TDBEdit;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
  private
    { Private declarations }
    FdmCliente: TdmCliente;

    procedure ConsultarDados;
    procedure DefinirDataSets;
  public
    { Public declarations }

    procedure OnNovoRegistro; override;
  end;

var
  frmCliente: TfrmCliente;

implementation

{$R *.dfm}

procedure TfrmCliente.ConsultarDados;
begin
  FdmCliente.ConsultarCliente;
end;

procedure TfrmCliente.DefinirDataSets;
begin
  dsDados.DataSet := FdmCliente.qyCliente;
end;

procedure TfrmCliente.FormCreate(Sender: TObject);
begin
  inherited;

  FdmCliente := TdmCliente.Create(Self);
  DefinirDataSets;
  ConsultarDados;
end;

procedure TfrmCliente.FormDestroy(Sender: TObject);
begin
  inherited;

  FreeAndNil(FdmCliente);
end;

procedure TfrmCliente.OnNovoRegistro;
begin
  inherited OnNovoRegistro;

  edtnm_cliente.SetFocus;
end;

end.

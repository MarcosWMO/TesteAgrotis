inherited dmCliente: TdmCliente
  OldCreateOrder = True
  object qyCliente: TADOQuery
    AfterOpen = qyClienteAfterOpen
    Parameters = <>
    Left = 168
    Top = 72
  end
end

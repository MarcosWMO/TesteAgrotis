unit udmProduto;

interface

uses
  System.SysUtils, System.Classes, udmBase, Data.DB, Data.Win.ADODB;

type
  TdmProduto = class(TdmBase)
    qyProduto: TADOQuery;
    procedure DataModuleCreate(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }

    procedure ConsultarProduto;
  end;

var
  dmProduto: TdmProduto;

implementation

{%CLASSGROUP 'Vcl.Controls.TControl'}

{$R *.dfm}

uses
  uProduto;

{ TdmProduto }

procedure TdmProduto.ConsultarProduto;
begin
  TProdutoSingleton.GetInstance.ConsultarProduto(qyProduto);
end;

procedure TdmProduto.DataModuleCreate(Sender: TObject);
begin
  inherited;

  DefinirConexao([qyProduto]);
end;

end.

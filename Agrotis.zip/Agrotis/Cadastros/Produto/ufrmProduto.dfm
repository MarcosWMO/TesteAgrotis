inherited frmProduto: TfrmProduto
  Caption = 'Cadastro de Produto'
  ClientHeight = 211
  ClientWidth = 497
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  ExplicitWidth = 513
  ExplicitHeight = 250
  PixelsPerInch = 96
  TextHeight = 13
  inherited navDados: TDBNavigator
    Width = 497
    Hints.Strings = ()
    ExplicitWidth = 497
  end
  inherited pnlFundo: TPanel
    Width = 497
    Height = 186
    ExplicitWidth = 497
    ExplicitHeight = 186
    inherited pcPrimario: TPageControl
      Width = 495
      Height = 184
      ActivePage = tsDados
      ExplicitWidth = 495
      ExplicitHeight = 184
      inherited tsConsulta: TTabSheet
        ExplicitWidth = 487
        ExplicitHeight = 156
        inherited grConsulta: TDBGrid
          Width = 487
          Height = 156
          DataSource = dsDados
          Columns = <
            item
              Expanded = False
              FieldName = 'cd_produto'
              Title.Caption = 'Produto'
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'nm_produto'
              Title.Caption = 'Descri'#231#227'o'
              Width = 399
              Visible = True
            end>
        end
      end
      inherited tsDados: TTabSheet
        ExplicitWidth = 487
        ExplicitHeight = 156
        object lblCodigo: TLabel
          Left = 3
          Top = 2
          Width = 33
          Height = 13
          Caption = 'C'#243'digo'
        end
        object lblDescricao: TLabel
          Left = 126
          Top = 2
          Width = 46
          Height = 13
          Caption = 'Descri'#231#227'o'
        end
        object edtcd_produto: TDBEdit
          Left = 3
          Top = 16
          Width = 121
          Height = 21
          TabStop = False
          DataField = 'cd_produto'
          DataSource = dsDados
          Enabled = False
          ReadOnly = True
          TabOrder = 0
        end
        object edtnm_produto: TDBEdit
          Left = 126
          Top = 16
          Width = 358
          Height = 21
          DataField = 'nm_produto'
          DataSource = dsDados
          TabOrder = 1
        end
      end
    end
  end
end

inherited dmProduto: TdmProduto
  inherited conConexaoPrincipal: TADOConnection
    Left = 88
  end
  object qyProduto: TADOQuery
    Parameters = <>
    Left = 72
    Top = 96
  end
end

unit ufrmProduto;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, ufrmCadastroBase, Data.DB, Vcl.Grids,
  Vcl.DBGrids, Vcl.ComCtrls, Vcl.ExtCtrls, Vcl.DBCtrls, udmProduto,
  Vcl.StdCtrls, Vcl.Mask;

type
  TfrmProduto = class(TfrmCadastroBase)
    edtcd_produto: TDBEdit;
    lblCodigo: TLabel;
    lblDescricao: TLabel;
    edtnm_produto: TDBEdit;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
  private
    { Private declarations }
    FdmProduto: TdmProduto;

    procedure ConsultarDados;
    procedure DefinirDataSets;
  public
    { Public declarations }

    procedure OnNovoRegistro; override;
  end;

var
  frmProduto: TfrmProduto;

implementation

{$R *.dfm}

procedure TfrmProduto.ConsultarDados;
begin
  FdmProduto.ConsultarProduto;
end;

procedure TfrmProduto.DefinirDataSets;
begin
  dsDados.DataSet := FdmProduto.qyProduto;
end;

procedure TfrmProduto.FormCreate(Sender: TObject);
begin
  inherited;

  FdmProduto := TdmProduto.Create(Self);
  DefinirDataSets;
  ConsultarDados;
end;

procedure TfrmProduto.FormDestroy(Sender: TObject);
begin
  inherited;

  FreeAndNil(FdmProduto);
end;

procedure TfrmProduto.OnNovoRegistro;
begin
  inherited OnNovoRegistro;

  edtnm_produto.SetFocus;
end;

end.

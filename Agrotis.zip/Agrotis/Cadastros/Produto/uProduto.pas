unit uProduto;

interface

uses
  uModel, FireDAC.Comp.Client, uSingleton,  Data.Win.ADODB;
type
  TProduto = class(TModel)
  private
    { private declarations }
  public
    { public declarations }
    procedure ConsultarProduto(const poQuery: TADOQuery;
      const picd_Produto: Int64 = 0);
  end;

  TProdutoSingleton = class(TSingleton<TProduto>);


implementation

{ TProduto }

procedure TProduto.ConsultarProduto(const poQuery: TADOQuery;
  const picd_Produto: Int64);
begin
  if Assigned(poQuery) then
  begin
    poQuery.Close;
    poQuery.SQL.Text :=
      'SELECT produto.cd_produto,' + sLineBreak +
      '       produto.nm_produto' + sLineBreak +
      '  FROM produto' + sLineBreak +
      ' WHERE (:cd_produto = 0 OR produto.cd_produto = :cd_produto)';
    poQuery.Parameters.ParamByName('cd_produto').Value := piCd_Produto;
    poQuery.Open;
  end;
end;

initialization

finalization
  TProdutoSingleton.ReleaseInstance;

end.
